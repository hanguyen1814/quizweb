{/* <div class="tab-pane fade" id="nav-taketest" role="tabpanel">
                                        <div class="alert alert-warning">
                                            <span class="fa-solid fa-exclamation-circle"></span> Sẵn sàng để bắt đầu làm
                                            full test? Để đạt được kết quả tốt nhất, bạn cần dành ra 40
                                            phút cho bài test này.
                                        </div>
                                        <br>
                                        <a class="btn btn-primary" href="/tests/2010/start/">
                                            BẮT ĐẦU THI
                                        </a>
                                    </div> */}
let btn = document.querySelector("#nav-taketest a");
btn.href = "/tests/2010/start/";
                                